package com.reljicd.controller;

import static org.apache.commons.codec.digest.MessageDigestAlgorithms.SHA_256;

import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.digest.DigestUtils;

import com.reljicd.exception.NotEnoughProductsInStockException;
import com.reljicd.model.PaymentDetails;
import com.reljicd.service.ProductService;
import com.reljicd.service.ShoppingCartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ShoppingCartController {

    private final ShoppingCartService shoppingCartService;

    private final ProductService productService;

    @Autowired
    public ShoppingCartController(ShoppingCartService shoppingCartService, ProductService productService) {
        this.shoppingCartService = shoppingCartService;
        this.productService = productService;
    }

    @GetMapping("/shoppingCart")
    public ModelAndView shoppingCart() {
        ModelAndView modelAndView = new ModelAndView("/shoppingCart");
        modelAndView.addObject("products", shoppingCartService.getProductsInCart());
        modelAndView.addObject("total", shoppingCartService.getTotal().toString());
        return modelAndView;
    }

    @GetMapping("/shoppingCart/addProduct/{productId}")
    public ModelAndView addProductToCart(@PathVariable("productId") Long productId) {
        productService.findById(productId).ifPresent(shoppingCartService::addProduct);
        return shoppingCart();
    }

    @GetMapping("/shoppingCart/removeProduct/{productId}")
    public ModelAndView removeProductFromCart(@PathVariable("productId") Long productId) {
        productService.findById(productId).ifPresent(shoppingCartService::removeProduct);
        return shoppingCart();
    }

    @GetMapping("/shoppingCart/checkout")
    public ModelAndView checkout() {
        ModelAndView modelAndView = new ModelAndView("/payment");
        String total = shoppingCartService.getTotal().toString();
        modelAndView.addObject("products", shoppingCartService.getProductsInCart());
        modelAndView.addObject("total", total);
        
        PaymentDetails pmtDet = new PaymentDetails();
        pmtDet.setAmount(total);
        pmtDet.setOrderNumber("1");
        
        modelAndView.addObject("paymentDetails", pmtDet);
/*        
        String digest = "";
		try {
			digest = new DigestUtils(SHA_256).digestAsHex(("6pKF4jkv97zmqBJ3ZL8gUw5DfT2NMQ|" +
					"13466|" + 
		            "http://local.localhost:8080/paymentSuccess|" + 
					"http://local.localhost:8080/paymentCancel|" + 
		            "1|" +
		            "MERCHANT_ID,URL_SUCCESS,URL_CANCEL,ORDER_NUMBER,PARAMS_IN,PARAMS_OUT,AMOUNT|" +
		            "PAYMENT_ID,TIMESTAMP,STATUS|" + 
		            total).getBytes("ISO-8859-1")).toUpperCase();
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        modelAndView.addObject("authcode", digest);
*/        
        
        return modelAndView;
    }
    
    @GetMapping("/shoppingCart/paymentSuccess")
    public ModelAndView paymentSuccess() {
        try {
            shoppingCartService.checkout();
        } catch (NotEnoughProductsInStockException e) {
            return shoppingCart().addObject("outOfStockMessage", e.getMessage());
        }

        ModelAndView modelAndView = new ModelAndView("redirect:/home");
        return modelAndView;
    }
    
    @GetMapping("/shoppingCart/paymentCancel")
    public ModelAndView paymentCancel() {
        ModelAndView modelAndView = new ModelAndView("/shoppingCart");
        modelAndView.addObject("products", shoppingCartService.getProductsInCart());
        modelAndView.addObject("total", shoppingCartService.getTotal().toString());
        modelAndView.addObject("message", "Your payment has not been processed");
        return modelAndView;
    }    
}
