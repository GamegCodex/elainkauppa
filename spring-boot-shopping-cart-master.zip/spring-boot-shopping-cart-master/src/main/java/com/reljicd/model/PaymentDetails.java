package com.reljicd.model;

import static org.apache.commons.codec.digest.MessageDigestAlgorithms.SHA_256;

import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.digest.DigestUtils;

public class PaymentDetails {
	private String merchantId = "13466";
	private String urlSuccess = "http://www.gameg.fi:8080/shoppingCart/paymentSuccess";
	private String urlCancel = "http://www.gameg.fi:8080/shoppingCart/paymentCancel";
	private String orderNumber;
	private String paramsIn = "MERCHANT_ID,URL_SUCCESS,URL_CANCEL,ORDER_NUMBER,PARAMS_IN,PARAMS_OUT,AMOUNT";
	private String paramsOut = "PAYMENT_ID,TIMESTAMP,STATUS";
	private String amount;
	public String getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}
	public String getUrlSuccess() {
		return urlSuccess;
	}
	public void setUrlSuccess(String urlSuccess) {
		this.urlSuccess = urlSuccess;
	}
	public String getUrlCancel() {
		return urlCancel;
	}
	public void setUrlCancel(String urlCancel) {
		this.urlCancel = urlCancel;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getParamsIn() {
		return paramsIn;
	}
	public void setParamsIn(String paramsIn) {
		this.paramsIn = paramsIn;
	}
	public String getParamsOut() {
		return paramsOut;
	}
	public void setParamsOut(String paramsOut) {
		this.paramsOut = paramsOut;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	
	public String getAuthcode() { 
		String digest = "";
		try {
			digest = new DigestUtils(SHA_256).digestAsHex(("6pKF4jkv97zmqBJ3ZL8gUw5DfT2NMQ|" +
					merchantId +  "|" + 
		            urlSuccess + "|" + 
					urlCancel + "|" + 
		            orderNumber + "|" +
		            paramsIn + "|" +
		            paramsOut + "|" + 
		            amount).getBytes("ISO-8859-1")).toUpperCase();
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return digest;
	}
	
}
