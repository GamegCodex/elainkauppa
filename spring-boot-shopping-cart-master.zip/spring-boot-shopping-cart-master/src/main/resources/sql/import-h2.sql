-- password in plaintext: "password"
INSERT INTO USER (user_id, password, email, username, name, last_name, active)
VALUES
  (1, '$2a$06$OAPObzhRdRXBCbk7Hj/ot.jY3zPwR8n7/mfLtKIgTzdJa4.6TwsIm', 'user@mail.com', 'user', 'Name', 'Surname',
   1);
-- password in plaintext: "password"
INSERT INTO USER (user_id, password, email, username, name, last_name, active)
VALUES
  (2, '$2a$06$OAPObzhRdRXBCbk7Hj/ot.jY3zPwR8n7/mfLtKIgTzdJa4.6TwsIm', 'johndoe@gmail.com', 'johndoe', 'John', 'Doe', 1);
-- password in plaintext: "password"
INSERT INTO USER (user_id, password, email, username, name, last_name, active)
VALUES (3, '$2a$06$OAPObzhRdRXBCbk7Hj/ot.jY3zPwR8n7/mfLtKIgTzdJa4.6TwsIm', 'name@gmail.com', 'namesurname', 'Name',
        'Surname', 1);

INSERT INTO ROLE (role_id, role)
VALUES (1, 'ROLE_ADMIN');
INSERT INTO ROLE (role_id, role)
VALUES (2, 'ROLE_USER');

INSERT INTO USER_ROLE (user_id, role_id)
VALUES (1, 1);
INSERT INTO USER_ROLE (user_id, role_id)
VALUES (1, 2);
INSERT INTO USER_ROLE (user_id, role_id)
VALUES (2, 2);
INSERT INTO USER_ROLE (user_id, role_id)
VALUES (3, 2);

INSERT INTO PRODUCT (product_id, name, description, imagefile, quantity, price)
VALUES (1, 'Kisu Naksu', 'Murkinaa Kissalle', 'purenatural-cat-purenatural-adult-chicken-dc.jpg', 3, 25.75);

INSERT INTO PRODUCT (product_id, name, description, imagefile, quantity, price)
VALUES (2, 'Hammasharja', 'Puruluu koiralle','whimzees-tugg-risben-8d.jpg', 5, 4.59);

INSERT INTO PRODUCT (product_id, name, description, imagefile, quantity, price)
VALUES (3, 'Whiskas', 'Kuivaruoka kissalle', 'catfood1.jpeg', 16, 15.99);

INSERT INTO PRODUCT (product_id, name, description, imagefile, quantity, price)
VALUES (4, 'Meow Mix', 'Kuivaruoka kissalle', 'catfood2.jpeg', 4, 10.99);

INSERT INTO PRODUCT (product_id, name, description, imagefile, quantity, price)
VALUES (5, 'Brit Premium', 'Perhelautanen', 'catfood3.jpeg', 8, 25.45);

INSERT INTO PRODUCT (product_id, name, description, imagefile, quantity, price)
VALUES (6, 'Purina Gourmet', 'Kuivaruoka kissalle', 'catfood4.jpeg', 6, 23.45);

INSERT INTO PRODUCT (product_id, name, description, imagefile, quantity, price)
VALUES (7, 'Canidae', 'Kuivaruoka koiralle', 'canidae.jpg', 7, 45.00);

